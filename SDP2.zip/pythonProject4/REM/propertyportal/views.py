from django.contrib.auth.models import User
from django.shortcuts import render,redirect
from .models import PropertyDetails
from .forms import Addproperty,Register
# Create your views here.


def home(request):
    return render(request, 'propertyportal/Home.html')


def login(request):
    return render(request, 'propertyportal/Login.html')


def properties(request):
    return render(request, 'propertyportal/Properties.html')


def cards(request):
    return render(request, 'propertyportal/Cards.html')


def adddata(request):
    if request.method=="POST":
        form = Addproperty(request.POST)
        if form.is_valid():
            form.save()
            return redirect('info')
    else:
        form=Addproperty()

    return render(request,'propertyportal/adddata.html',{'title':'NewProperty','form':form})


def register(request):
    if request.method=="POST":
        form = Register(request.POST)
        if form.is_valid():
            form.save()
    else:
        form= Register()

    return render(request,'/signup_page.html',{'title':'NewUser','form':form})


def info(request):
    return render(request,'propertyportal/Information.html',{'title':'view','data':PropertyDetails.objects.all()})