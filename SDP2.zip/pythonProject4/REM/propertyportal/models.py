from django.db import models
from django import forms
# Create your models here.
class PropertyDetails(models.Model):
    name=models.CharField(max_length=30)
    propertytype = models.CharField(max_length=30)
    address = models.CharField(max_length=30)
    price = models.IntegerField()
    phone = models.BigIntegerField()
    def __str__(self):
        return self.name

class RegisteredUserDetails(models.Model):
    username=models.CharField(max_length=30)
    email = models.EmailField()
    phone = models.BigIntegerField()
    def __str__(self):
        return self.name