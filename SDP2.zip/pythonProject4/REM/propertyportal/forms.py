from django import forms
from .models import PropertyDetails,RegisteredUserDetails

class Addproperty(forms.ModelForm):
    class Meta:
        model=PropertyDetails
        fields=('name','propertytype','address','price','phone')

class Register(forms.ModelForm):
    class Meta:
        model=RegisteredUserDetails
        fields=('username','email','phone')