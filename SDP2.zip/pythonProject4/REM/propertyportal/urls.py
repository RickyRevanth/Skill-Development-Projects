from django.contrib import admin
from django.urls import path,include

from .import views

urlpatterns = [
    path('', views.home,name='home'),
    path('signup/', views.register,name='newUser'),
    path('login/', views.login),
    path('properties/', views.properties),
    path('cards/', views.cards),
    path('admin/', admin.site.urls),
    path('adddata/',views.adddata,name='newD'),
    path('info/',views.info,name='info'),
]